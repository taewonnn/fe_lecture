// 실행시킬 예제만 주석을 해제해 주세요
import example from './ex01';
// import example from './ex02';

example();
